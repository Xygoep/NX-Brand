/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, 
  LogOut, 
  Plus, 
  Trash2, 
  Edit, 
  ArrowUp, 
  ArrowDown, 
  Image as ImageIcon, 
  Send, 
  MessageSquare, 
  Instagram, 
  Phone, 
  PhoneCall,
  X, 
  Check, 
  Sparkles,
  ChevronDown,
  ShoppingBag
} from 'lucide-react';

interface Product {
  id: string;
  title: string;
  description: string;
  volumes: string[];
  colors: string[];
  price: string;
  image: string;
  order: number;
}

const DEFAULT_PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'NX Royal Oud',
    description: 'Глубокий восточный аромат с нотами редкого уда, кожи и пряной амбры. Изысканный выбор для истинных ценителей.',
    volumes: ['50ml', '100ml'],
    colors: ['Золотой', 'Черный матовый'],
    price: '14 500 ₽',
    image: 'https://images.unsplash.com/photo-1547887537-6158d64c35b3?q=80&w=1000&auto=format&fit=crop',
    order: 1
  },
  {
    id: '2',
    title: 'NX Velvet Crimson',
    description: 'Чувственный и страстный букет с нотами спелой вишни, розового перца и ванили.',
    volumes: ['30ml', '50ml', '100ml'],
    colors: ['Красный рубин', 'Золотой'],
    price: '12 900 ₽',
    image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?q=80&w=1000&auto=format&fit=crop',
    order: 2
  },
  {
    id: '3',
    title: 'NX Golden Sillage',
    description: 'Сияющий цитрусово-древесный аромат с нотами бергамота, белого мускуса и сандала.',
    volumes: ['50ml', '100ml'],
    colors: ['Золотой глянцевый'],
    price: '16 000 ₽',
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?q=80&w=1000&auto=format&fit=crop',
    order: 3
  }
];

export default function App() {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('nx_perfume_products');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return DEFAULT_PRODUCTS;
  });

  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    return localStorage.getItem('nx_is_admin') === 'true';
  });

  const [showLoginModal, setShowLoginModal] = useState(false);
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form state for add/edit
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formVolumes, setFormVolumes] = useState('50ml, 100ml');
  const [formColors, setFormColors] = useState('Золотой');
  const [formPrice, setFormPrice] = useState('12 000 ₽');
  const [formImage, setFormImage] = useState('');

  useEffect(() => {
    localStorage.setItem('nx_perfume_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('nx_is_admin', isAdmin ? 'true' : 'false');
  }, [isAdmin]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (usernameInput === 'Xvlne' && passwordInput === 'Xvlne2005') {
      setIsAdmin(true);
      setShowLoginModal(false);
      setUsernameInput('');
      setPasswordInput('');
      setLoginError('');
    } else {
      setLoginError('Неверный логин или пароль');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const openAddModal = () => {
    setEditingProduct(null);
    setFormTitle('');
    setFormDesc('');
    setFormVolumes('50ml, 100ml');
    setFormColors('Золотой');
    setFormPrice('12 000 ₽');
    setFormImage('https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=1000&auto=format&fit=crop');
    setShowAddModal(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormTitle(product.title);
    setFormDesc(product.description);
    setFormVolumes(product.volumes.join(', '));
    setFormColors(product.colors.join(', '));
    setFormPrice(product.price);
    setFormImage(product.image);
    setShowAddModal(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const volumesList = formVolumes.split(',').map(v => v.trim()).filter(Boolean);
    const colorsList = formColors.split(',').map(c => c.trim()).filter(Boolean);

    if (editingProduct) {
      setProducts(products.map(p => p.id === editingProduct.id ? {
        ...p,
        title: formTitle,
        description: formDesc,
        volumes: volumesList,
        colors: colorsList,
        price: formPrice,
        image: formImage || p.image
      } : p));
    } else {
      // New product added at the top or specified order
      const newProduct: Product = {
        id: Date.now().toString(),
        title: formTitle,
        description: formDesc,
        volumes: volumesList,
        colors: colorsList,
        price: formPrice,
        image: formImage || 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=1000&auto=format&fit=crop',
        order: products.length > 0 ? Math.min(...products.map(p => p.order)) - 1 : 1
      };
      setProducts([newProduct, ...products]);
    }
    setShowAddModal(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Удалить этот товар с витрины?')) {
      setProducts(products.filter(p => p.id !== id));
    }
  };

  const moveOrder = (index: number, direction: 'up' | 'down') => {
    const sorted = [...products].sort((a, b) => a.order - b.order);
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= sorted.length) return;

    const temp = sorted[index].order;
    sorted[index].order = sorted[targetIndex].order;
    sorted[targetIndex].order = temp;

    // also swap in array positions
    const item = sorted.splice(index, 1)[0];
    sorted.splice(targetIndex, 0, item);

    // re-assign orders sequentially
    const reordered = sorted.map((p, idx) => ({ ...p, order: idx + 1 }));
    setProducts(reordered);
  };

  const sortedProducts = [...products].sort((a, b) => a.order - b.order);

  const handleOrderClick = (productTitle: string) => {
    const message = encodeURIComponent(`Здравствуйте! Хочу заказать духи "${productTitle}" с витрины NX.`);
    window.open(`https://t.me/xygoep?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-red-600 text-white flex flex-col font-sans selection:bg-amber-300 selection:text-black">
      
      {/* Top Header */}
      <header className="w-full py-6 px-4 flex flex-col items-center justify-center relative z-20 border-b border-red-500/40 bg-red-700/60 backdrop-blur-md">
        <div className="flex flex-col items-center select-none">
          {/* Logo Monogram NX */}
          <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-amber-200 via-amber-400 to-amber-600 p-[2px] shadow-2xl">
            <div className="w-full h-full bg-red-950 rounded-full flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-red-900/80 to-black/90"></div>
              <span className="relative font-serif text-3xl md:text-4xl font-bold tracking-widest text-amber-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                NX
              </span>
            </div>
          </div>
          <div className="mt-4 bg-red-950/80 border border-amber-400/40 px-5 py-2.5 rounded-2xl shadow-xl flex flex-col items-center gap-1 max-w-sm mx-auto text-center">
            <span className="text-[11px] md:text-xs font-serif text-amber-200 uppercase tracking-widest font-semibold">
              ✦ Ручная работа • Индивидуальный заказ ✦
            </span>
            <span className="text-[10px] md:text-[11px] text-red-200 uppercase tracking-wider font-light">
              Бесплатная доставка по всей России
            </span>
          </div>
        </div>

        {/* Admin status / controls header */}
        {isAdmin && (
          <div className="mt-4 flex flex-wrap items-center justify-center gap-3 bg-red-900/90 border border-amber-400/40 px-4 py-2 rounded-full shadow-lg">
            <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-amber-400" /> Админ-панель
            </span>
            <button
              onClick={openAddModal}
              className="bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 transition shadow"
            >
              <Plus className="w-3.5 h-3.5" /> Добавить товар
            </button>
            <button
              onClick={handleLogout}
              className="bg-red-800 hover:bg-red-950 text-red-200 text-xs px-3 py-1 rounded-full flex items-center gap-1 transition border border-red-700"
            >
              <LogOut className="w-3 h-3" /> Выйти
            </button>
          </div>
        )}
      </header>

      {/* Main Showcase Feed (One item per view on mobile, full immersive showcase) */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-4 py-8 flex flex-col gap-12">
        {sortedProducts.length === 0 ? (
          <div className="text-center py-20 bg-red-700/40 rounded-3xl border border-red-500/30 p-8">
            <Sparkles className="w-12 h-12 text-amber-300 mx-auto mb-4 animate-pulse" />
            <h3 className="text-xl font-serif text-amber-200 mb-2">Витрина пуста</h3>
            <p className="text-red-200 text-sm mb-6">В данный момент товары не добавлены.</p>
            {isAdmin && (
              <button
                onClick={openAddModal}
                className="bg-amber-400 text-black font-bold px-6 py-3 rounded-full text-sm shadow-lg hover:bg-amber-300 transition"
              >
                Добавить первый аромат
              </button>
            )}
          </div>
        ) : (
          sortedProducts.map((product, index) => (
            <article 
              key={product.id}
              className="w-full bg-red-950/70 backdrop-blur-xl border border-amber-500/30 rounded-3xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex flex-col md:flex-row group transition-all duration-300 hover:border-amber-400/60"
            >
              {/* Product Image */}
              <div className="relative w-full md:w-1/2 h-[350px] md:h-[480px] bg-black/40 overflow-hidden flex items-center justify-center">
                <img 
                  src={product.image} 
                  alt={product.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-red-950 via-transparent to-transparent md:hidden"></div>
                
                {/* Admin Reorder / Edit buttons on image */}
                {isAdmin && (
                  <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/60 backdrop-blur-md p-2 rounded-2xl border border-amber-500/40 shadow-xl z-10">
                    <button
                      onClick={() => moveOrder(index, 'up')}
                      disabled={index === 0}
                      className="p-1.5 text-amber-300 hover:bg-amber-500/20 rounded-lg disabled:opacity-30 transition"
                      title="Выше"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => moveOrder(index, 'down')}
                      disabled={index === sortedProducts.length - 1}
                      className="p-1.5 text-amber-300 hover:bg-amber-500/20 rounded-lg disabled:opacity-30 transition"
                      title="Ниже"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => openEditModal(product)}
                      className="p-1.5 text-blue-300 hover:bg-blue-500/20 rounded-lg transition"
                      title="Редактировать"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(product.id)}
                      className="p-1.5 text-red-300 hover:bg-red-500/20 rounded-lg transition"
                      title="Удалить"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {/* Badge Number */}
                <div className="absolute top-4 left-4 bg-amber-400 text-black font-bold text-xs px-3 py-1 rounded-full shadow-lg tracking-wider">
                  #{index + 1}
                </div>
              </div>

              {/* Product Info */}
              <div className="w-full md:w-1/2 p-6 md:p-10 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-2xl md:text-3xl font-serif text-amber-200 font-bold tracking-wide">
                      {product.title}
                    </h2>
                    {product.price && (
                      <span className="text-lg md:text-xl font-bold text-white bg-red-900/80 px-3 py-1 rounded-xl border border-amber-500/30">
                        {product.price}
                      </span>
                    )}
                  </div>

                  <p className="text-red-100 text-sm md:text-base leading-relaxed mb-6 font-light opacity-95">
                    {product.description}
                  </p>

                  {/* Volumes & Colors */}
                  <div className="space-y-4 mb-8">
                    {product.volumes && product.volumes.length > 0 && (
                      <div>
                        <span className="text-xs uppercase tracking-widest text-amber-300/80 block mb-1 font-semibold">
                          Доступные объемы (ml):
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {product.volumes.map((vol, vIdx) => (
                            <span 
                              key={vIdx}
                              className="text-xs bg-red-900/60 border border-amber-500/40 text-amber-200 px-3 py-1 rounded-lg font-medium"
                            >
                              {vol}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {product.colors && product.colors.length > 0 && (
                      <div>
                        <span className="text-xs uppercase tracking-widest text-amber-300/80 block mb-1 font-semibold">
                          Варианты расцветки / флакона:
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {product.colors.map((col, cIdx) => (
                            <span 
                              key={cIdx}
                              className="text-xs bg-red-900/60 border border-amber-500/40 text-red-100 px-3 py-1 rounded-lg font-medium"
                            >
                              {col}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Order Button */}
                <div>
                  <button
                    onClick={() => handleOrderClick(product.title)}
                    className="w-full bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-bold py-3.5 px-6 rounded-2xl shadow-[0_10px_20px_rgba(251,191,36,0.3)] transition-all duration-300 flex items-center justify-center gap-2 group/btn text-sm tracking-wider uppercase"
                  >
                    <Send className="w-4 h-4 text-black group-hover/btn:translate-x-1 transition-transform" />
                    Заказать в Telegram
                  </button>
                  <p className="text-center text-[11px] text-red-300/70 mt-2">
                    Переход в прямой чат с менеджером @xygoep
                  </p>
                </div>

              </div>
            </article>
          ))
        )}
      </main>

      {/* Footer (Fixed at the bottom as requested, showing contacts & brand info) */}
      <footer className="w-full bg-red-950 border-t border-red-500/40 py-10 px-4 mt-auto">
        <div className="max-w-4xl mx-auto flex flex-col items-center text-center gap-6">
          {/* Contacts - Icons only */}
          <div className="flex items-center justify-center gap-6 mt-2">
            {/* WhatsApp */}
            <a 
              href="https://wa.me/79050223258" 
              target="_blank" 
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="w-12 h-12 rounded-full bg-red-900/90 hover:bg-red-800 border border-amber-500/40 flex items-center justify-center text-emerald-400 shadow-lg hover:scale-110 transition-all"
            >
              <Phone className="w-5 h-5" />
            </a>

            {/* Max */}
            <a 
              href="tel:+79050223258" 
              aria-label="Max (+79050223258)"
              className="w-12 h-12 rounded-full bg-red-900/90 hover:bg-red-800 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-lg hover:scale-110 transition-all"
            >
              <PhoneCall className="w-5 h-5" />
            </a>

            {/* Telegram */}
            <a 
              href="https://t.me/xygoep" 
              target="_blank" 
              rel="noopener noreferrer"
              aria-label="Telegram"
              className="w-12 h-12 rounded-full bg-red-900/90 hover:bg-red-800 border border-amber-500/40 flex items-center justify-center text-sky-400 shadow-lg hover:scale-110 transition-all"
            >
              <Send className="w-5 h-5" />
            </a>

            {/* Instagram */}
            <a 
              href="https://instagram.com/nx.blg" 
              target="_blank" 
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="w-12 h-12 rounded-full bg-red-900/90 hover:bg-red-800 border border-amber-500/40 flex items-center justify-center text-pink-400 shadow-lg hover:scale-110 transition-all"
            >
              <Instagram className="w-5 h-5" />
            </a>
          </div>

          <div 
            onClick={() => {
              if (!isAdmin) {
                setShowLoginModal(true);
              }
            }}
            className="text-[11px] text-red-300/60 mt-4 border-t border-red-900 pt-4 w-full cursor-pointer select-none hover:text-amber-300 transition"
          >
            © {new Date().getFullYear()} NX Perfume. Все права защищены.
          </div>
        </div>
      </footer>

      {/* Admin Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-red-950 border border-amber-500/50 rounded-3xl p-6 md:p-8 w-full max-w-md shadow-2xl relative">
            <button 
              onClick={() => setShowLoginModal(false)}
              className="absolute top-4 right-4 text-red-300 hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-amber-400 text-black rounded-full flex items-center justify-center font-bold mx-auto mb-3 shadow">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-serif text-amber-200 font-bold">Вход для администратора</h3>
              <p className="text-xs text-red-200 mt-1">Введите учетные данные NX</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Имя пользователя</label>
                <input 
                  type="text"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  placeholder="•••••"
                  className="w-full bg-red-900/50 border border-amber-500/30 rounded-xl px-4 py-2.5 text-white placeholder-red-300/40 text-sm focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Пароль</label>
                <input 
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-red-900/50 border border-amber-500/30 rounded-xl px-4 py-2.5 text-white placeholder-red-300/40 text-sm focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              {loginError && (
                <p className="text-xs text-red-300 bg-red-900/80 p-2.5 rounded-xl border border-red-500 text-center font-medium">
                  {loginError}
                </p>
              )}

              <button
                type="submit"
                className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold py-3 rounded-xl shadow-lg transition text-sm tracking-wider uppercase"
              >
                Войти в систему
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-red-950 border border-amber-500/50 rounded-3xl p-6 md:p-8 w-full max-w-lg shadow-2xl relative my-8">
            <button 
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 text-red-300 hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-serif text-amber-200 font-bold mb-6">
              {editingProduct ? 'Редактировать товар' : 'Добавить новый аромат'}
            </h3>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Название парфюма</label>
                <input 
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="NX Royal Oud"
                  className="w-full bg-red-900/50 border border-amber-500/30 rounded-xl px-4 py-2 text-white placeholder-red-300/40 text-sm focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Описание</label>
                <textarea 
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="Описание аромата, ноты..."
                  rows={3}
                  className="w-full bg-red-900/50 border border-amber-500/30 rounded-xl px-4 py-2 text-white placeholder-red-300/40 text-sm focus:outline-none focus:border-amber-400 resize-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Объемы (мл)</label>
                  <input 
                    type="text"
                    value={formVolumes}
                    onChange={(e) => setFormVolumes(e.target.value)}
                    placeholder="50ml, 100ml"
                    className="w-full bg-red-900/50 border border-amber-500/30 rounded-xl px-4 py-2 text-white placeholder-red-300/40 text-sm focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Цена</label>
                  <input 
                    type="text"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    placeholder="12 000 ₽"
                    className="w-full bg-red-900/50 border border-amber-500/30 rounded-xl px-4 py-2 text-white placeholder-red-300/40 text-sm focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Расцветка / Флакон</label>
                <input 
                  type="text"
                  value={formColors}
                  onChange={(e) => setFormColors(e.target.value)}
                  placeholder="Золотой, Черный матовый"
                  className="w-full bg-red-900/50 border border-amber-500/30 rounded-xl px-4 py-2 text-white placeholder-red-300/40 text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-amber-300/80 mb-1 font-semibold">Фото товара (из галереи или URL)</label>
                <div className="flex gap-2 items-center">
                  <input 
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="upload-photo-input"
                  />
                  <label 
                    htmlFor="upload-photo-input"
                    className="bg-red-900 hover:bg-red-800 border border-amber-500/40 text-amber-200 text-xs px-4 py-2.5 rounded-xl cursor-pointer flex items-center gap-2 transition"
                  >
                    <ImageIcon className="w-4 h-4" /> Выбрать из галереи
                  </label>
                  <input 
                    type="text"
                    value={formImage}
                    onChange={(e) => setFormImage(e.target.value)}
                    placeholder="или вставьте URL картинки"
                    className="flex-1 bg-red-900/50 border border-amber-500/30 rounded-xl px-3 py-2 text-white placeholder-red-300/40 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>
                {formImage && (
                  <div className="mt-3 w-full h-32 rounded-xl overflow-hidden border border-amber-500/30 bg-black/40">
                    <img src={formImage} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-red-900 hover:bg-red-800 text-red-200 font-bold py-3 rounded-xl transition text-sm border border-red-700"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-amber-400 hover:bg-amber-300 text-black font-bold py-3 rounded-xl shadow-lg transition text-sm tracking-wider uppercase"
                >
                  {editingProduct ? 'Сохранить' : 'Добавить'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
